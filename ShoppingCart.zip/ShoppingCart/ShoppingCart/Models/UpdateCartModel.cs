﻿namespace ShoppingCart.Models
{
    public class UpdateCartModel
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
    }
}
